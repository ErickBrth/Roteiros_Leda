package sorting.divideAndConquer;


import sorting.AbstractSorting;
import util.Util;

/**
 * Quicksort is based on the divide-and-conquer paradigm. The algorithm chooses
 * a pivot element and rearranges the elements of the interval in such a way
 * that all elements lesser than the pivot go to the left part of the array and
 * all elements greater than the pivot, go to the right part of the array. Then
 * it recursively sorts the left and the right parts. Notice that if the list
 * has length == 1, it is already sorted.
 */
public class QuickSort<T extends Comparable<T>> extends AbstractSorting<T> {

	@Override
	public void sort(T[] array, int leftIndex, int rightIndex) {
		if (leftIndex < rightIndex && array.length > 1 && array != null) {
			int index_pivot = partition(array, leftIndex, rightIndex);
			sort(array, leftIndex, index_pivot - 1);
			sort(array, index_pivot + 1, rightIndex);	
		}
	}

	public int partition(T[] values, int left, int right) {
		int range = right - left + 1;
        int rand_pivot_index = (int)(Math.random() * range) + left;

        // troca o valor aleat�rio escolhido com a primeira posi��o
        Util.swap(values, left, rand_pivot_index);

        T pivot = values[left];
        int i = left;

        for (int j = left + 1; j <= right; j++) {
            if (values[j].compareTo(pivot) <= 0) {
                i+=1;
                Util.swap(values, i, j);
            }
        }

        // troca pivot (values[left]) com i.
        Util.swap(values, left, i);
        
        return i; 
	}
}
